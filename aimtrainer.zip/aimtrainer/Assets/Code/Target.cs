using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Target : MonoBehaviour
{

    // Start is called before the first frame update
    public void Hit()
    {
        transform.position = new Vector3(Random.Range(-5, 5), 1, 0);
    } 
}
